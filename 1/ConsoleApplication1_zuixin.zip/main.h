#ifndef MIAN_H
#define MAIN_H

#include<iostream>
#include<process.h>
#include<string>
#include <vector>
#include <conio.h>
#include<stdio.h>
#include <stdlib.h>
#include <windows.h>//�Ի���
#include <cstdio>//�Ի���


void Returns_function(void);



#endif // !MIAN_H

